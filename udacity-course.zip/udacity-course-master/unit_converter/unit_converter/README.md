# Unit Converter App

A unit converter app that converts units in 8 categories (Length, Area, Volume, Mass, Time, Digital Storage, Energy, and Currency).
Currency conversions are entirely mock data and come from `flutter.udacity.com/currency`.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).

## Contributing
See the [Contributing Guidelines for Flutter](https://github.com/flutter/flutter/blob/master/CONTRIBUTING.md)

## Credits

### Font
[Raleway](https://fonts.google.com/specimen/Raleway)

### Images
Designed within Google

